import json
import boto3
import os
from botocore.exceptions import ClientError
from datetime import datetime
import logging
from typing import Dict, List, Union, Tuple

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
s3 = boto3.client('s3')
sqs = boto3.client('sqs')
dynamodb = boto3.resource('dynamodb')
bedrock = boto3.client('bedrock-runtime')


def update_dynamodb_error(table, request_id, error_message):
    table.update_item(
        Key={'request_id': request_id},
        UpdateExpression="SET request_status = :status, updated_at = :time, error_message = :error",
        ExpressionAttributeValues={
            ':status': 'FAILED',
            ':time': datetime.utcnow().isoformat(),
            ':error': error_message
        }
    )
    logger.info(f"Updated DynamoDB for request {request_id}: status set to FAILED")

def get_request_data(s3_client, bucket: str, request_id: str) -> Dict:
    """
    Retrieve and validate request data from S3.

    Args:
        s3_client: Boto3 S3 client instance
        bucket (str): Name of the S3 bucket containing the request data
        request_id (str): Unique identifier for the request

    Returns:
        Dict: Validated JSON data containing the request parameters

    Raises:
        ValueError: If JSON is invalid or S3 retrieval fails
        json.JSONDecodeError: If the S3 object contains invalid JSON
    """
    try:
        response = s3_client.get_object(Bucket=bucket, Key=f'{request_id}.json')
        request_data_str = response['Body'].read().decode('utf-8')
        request_data = json.loads(request_data_str)
        logger.info(f"Request data for {request_id}: {json.dumps(request_data)}")
        return request_data
    except json.JSONDecodeError:
        raise ValueError(f"Invalid JSON format for request {request_id}")
    except Exception as e:
        raise ValueError(f"Failed to retrieve request data: {str(e)}")

def update_request_status(table, request_id: str, status: str) -> None:
    """
    Update request status and timestamp in DynamoDB.

    Args:
        table: DynamoDB table instance
        request_id (str): Unique identifier for the request
        status (str): New status to set ('IN_PROGRESS', 'COMPLETED', 'FAILED')

    Raises:
        Exception: If DynamoDB update operation fails
    """
    table.update_item(
        Key={'request_id': request_id},
        UpdateExpression="SET request_status = :status, updated_at = :time",
        ExpressionAttributeValues={
            ':status': status,
            ':time': datetime.utcnow().isoformat()
        }
    )
    logger.info(f"Updated DynamoDB for request {request_id}: status set to {status}")

def prepare_bedrock_params(request_data: Dict) -> Dict:
    """
    Extract and validate parameters for Bedrock API call.

    Args:
        request_data (Dict): Request data containing:
            - messages (List): List of message objects for the conversation
            - model_id (str): Bedrock model identifier
            - system (List, optional): System prompt messages

    Returns:
        Dict: Formatted parameters for Bedrock API call containing:
            - modelId (str): The Bedrock model identifier
            - messages (List): The conversation messages
            - system (List, optional): System prompt if provided

    Raises:
        ValueError: If required fields (messages or model_id) are missing
    """
    messages = request_data.get('messages', [])
    model_id = request_data.get('model_id')
    system = request_data.get('system', [])

    if not (messages and model_id):
        raise ValueError("Missing required fields: 'messages' or 'model_id'")

    params = {
        "modelId": model_id,
        "messages": messages,
    }
    
    if system:
        params["system"] = system
        
    return params

def process_bedrock_response(response: Dict) -> Union[Dict, str]:
    """
    Process and validate Bedrock API response.

    Args:
        response (Dict): Raw response from Bedrock API containing:
            - output (Dict): Output container
            - message (Dict): Message container with content

    Returns:
        Union[Dict, str]: Either:
            - Dict: Parsed JSON response if completion is valid JSON
            - str: Raw completion text if not valid JSON

    Raises:
        ValueError: If response structure is invalid or missing required fields
    """
    if 'output' not in response or 'message' not in response['output']:
        raise ValueError("Invalid response structure from Bedrock API")

    message_content = response['output']['message']
    
    if 'content' not in message_content or not message_content['content']:
        raise ValueError("No content in message response")

    completion = message_content['content'][0].get('text', "No content returned")

    try:
        return json.loads('{' + completion), response['metrics'], response['usage'] # the '{' is needed to keep claude from being chatty
    except json.JSONDecodeError:
        logger.warning("Failed to parse completion as JSON")
        return completion

def process_record(record: Dict, s3, dynamodb_table, bedrock_client, bucket: str) -> Tuple[str, List, Union[Dict, str]]:
    """
    Process a single SQS record through the entire workflow.

    Args:
        record (Dict): SQS record containing the message body
        s3: Boto3 S3 client instance
        dynamodb_table: DynamoDB table instance
        bedrock_client: Bedrock client instance
        bucket (str): Name of the S3 bucket

    Returns:
        Tuple[str, List, Union[Dict, str]]: Tuple containing:
            - request_id (str): Unique identifier for the request
            - messages (List): Original messages from the request
            - result (Union[Dict, str]): Processed Bedrock response

    Raises:
        Exception: If any step in the processing pipeline fails
    """
    message = json.loads(record['body'])
    request_id = message['request_id']
    
    try:
        request_data = get_request_data(s3, bucket, request_id)
        update_request_status(dynamodb_table, request_id, 'IN_PROGRESS')
        
        params = prepare_bedrock_params(request_data)
        bedrock_response = bedrock_client.converse(**params)
        logger.debug(f"Raw Bedrock response: {bedrock_response}")
        
        result = process_bedrock_response(bedrock_response)

        
        return request_id, result , bedrock_response['metrics'], bedrock_response['usage']
        
    except Exception as e:
        logger.error(f"Error processing request {request_id}: {str(e)}")
        update_request_status(dynamodb_table, request_id, 'FAILED')
        raise

def handler(event: Dict, context) -> Dict:
    """
    Main Lambda handler for processing Bedrock requests.

    Args:
        event (Dict): Lambda event containing:
            - Records (List): List of SQS records to process
        context: Lambda context object (unused)

    Returns:
        Dict: Response object containing:
            - statusCode (int): HTTP status code (200 for success)
            - body (str): JSON-encoded success message

    Note:
        This function:
        1. Processes each record in the SQS batch
        2. Updates DynamoDB status throughout processing
        3. Calls Bedrock API for each request
        4. Sends results to a results SQS queue
        5. Handles errors and updates status accordingly
    """
    # Environment variables
    S3_BUCKET = os.environ['S3_BUCKET_NAME']
    DYNAMODB_TABLE = os.environ['DYNAMODB_TABLE_NAME']
    RESULTS_QUEUE_URL = os.environ['RESULTS_QUEUE_URL']

    logger.debug(f"Event: {event}")
    for record in event['Records']:
        request_id = None
        try:
            # Extract request_id before processing
            message = json.loads(record['body'])
            request_id = message['request_id']
            
            # Process the record
            request_id, result, metrics, usage = process_record(record, s3, dynamodb.Table(DYNAMODB_TABLE), bedrock, S3_BUCKET)
            
            # Prepare and send SQS message
            sqs_message = {
                'request_id': request_id,
                'original_request': result,
                'result': result,
                'metrics': metrics,
                'usage': usage
            }

            sqs_response = sqs.send_message(
                QueueUrl=RESULTS_QUEUE_URL,
                MessageBody=json.dumps(sqs_message) 
            )
            logger.info(f"Message sent to SQS. MessageId: {sqs_response['MessageId']}")

            # Update DynamoDB to mark success
            update_request_status(dynamodb.Table(DYNAMODB_TABLE), request_id, 'COMPLETED')
            
        except Exception as e:
            error_msg = f"Unexpected error processing request {request_id or 'UNKNOWN'}: {str(e)}"
            logger.error(error_msg, exc_info=True)
            if request_id:  # Only update DynamoDB if we have a request_id
                update_dynamodb_error(dynamodb.Table(DYNAMODB_TABLE), request_id, str(e))
            raise
        
    return {
        'statusCode': 200,
        'body': json.dumps(f'Processing complete for {request_id} with metrics {metrics} and usage {usage}')
    }

# if __name__ == "__main__":
#     os.environ['S3_BUCKET_NAME'] = 'brrequestsmootherstack-bedrockcallsbucket5aed0cf9-flxvjkwbkxl4'
#     os.environ['DYNAMODB_TABLE_NAME'] = 'BrRequestSmootherStack-RequestsTable419243C7-1IG49OBTTYD64'
#     os.environ['RESULTS_QUEUE_URL'] = 'https://sqs.us-east-1.amazonaws.com/141051459377/BrRequestSmootherStack-BedrockResultsQueue64EE975B-kc8aot8jIcmC'
#     e = {'Records': [{'messageId': '4b9bec10-101c-406c-8f28-bb5b14827692', 'receiptHandle': 'AQEBPKb/Nc6e+NhUIypcaDL17avsgDAFepV7i1lQcrEjD1Z8oE65S6kUHfYECbWoFIudoejlBtpF3Q38iKOpZXL7/6bVVC/6gMoI2+SBXbtY9Giqk1t06PktMy6XqF8Q5F3pEuc2le4WtI1uCcnwm1AdwmzArW/h9+cmA57ndJUzGKCbxnmXafZZOqIvVYZjukGGc6qQLHQlcI9b4mWwzP4o77uYny5axL/maZ60GjjjU2Zxo0ygVV0hl2PBo11mtLvA1a32JZITTkP6GPXYpMSGP8Z/goPmBoHQ0+bS8dn3LOFqKNqp9SjxSTPVSkj6R67QWvaPmmS1yftllxes6UGaYs23XlNx9XG4ULnXxs4YUdE=', 'body': '{"request_id": "93b8b5e3-acc5-4109-b9c4-a82de3f145b8", "timestamp": "2024-11-09T00:35:17.966362", "data": {"original_request": {"messages": [{"content": [{"text": "<document>Euler\'s_identity\\n\\nIn mathematics, Euler\'s identity (also known as Euler\'s equation) is the equality e i \\u03c0 + 1 = 0 {\\\\displaystyle e^{i\\\\pi }+1=0} where e {\\\\displaystyle e} is Euler\'s number, the base of natural logarithms, i {\\\\displaystyle i} is the imaginary unit, which by definition satisfies i 2 = \\u2212 1 {\\\\displaystyle i^{2}=-1} , and \\u03c0 {\\\\displaystyle \\\\pi } is pi, the ratio of the circumference of a circle to its diameter. Euler\'s identity is named after the Swiss mathematician Leonhard Euler. It is a special case of Euler\'s formula e i x = cos \\u2061 x + i sin \\u2061 x {\\\\displaystyle e^{ix}=\\\\cos x+i\\\\sin x} when evaluated for x = \\u03c0 {\\\\displaystyle x=\\\\pi } . Euler\'s identity is considered to be an exemplar of mathematical beauty as it shows a profound connection between the most fundamental numbers in mathematics. In addition, it is directly used in a proof that \\u03c0 is transcendental, which implies the impossibility of squaring the circle. Mathematical beauty Euler\'s identity is often cited as an example of deep mathematical beauty. Three of the basic arithmetic operations occur exactly once each: addition, multiplication, and exponentiation. The identity also links five fundamental mathematical constants: The number 0, the additive identity The number 1, the multiplicative identity The number \\u03c0 (\\u03c0 = 3.1415...), the fundamental circle constant The number e (e = 2.718...), also known as Euler\'s number, which occurs widely in mathematical analysis The number i, the imaginary unit such that i 2 = \\u2212 1 {\\\\displaystyle i^{2}=-1} The equation is often given in the form of an expression set equal to zero, which is common practice in several areas of mathematics. Stanford University mathematics professor Keith Devlin has said, \\"like a Shakespearean sonnet that captures the very essence of love, or a painting that brings out the beauty of the human form that is far more than just skin deep, Euler\'s equation reaches down into the very depths of existence\\". And Paul Nahin, a professor emeritus at the University of New Hampshire, who has written a book dedicated to Euler\'s formula and its applications in Fourier analysis, describes Euler\'s identity as being \\"of exquisite beauty\\". Mathematics writer Constance Reid has opined that Euler\'s identity is \\"the most famous formula in all mathematics\\". And Benjamin Peirce, a 19th-century American philosopher, mathematician, and professor at Harvard University, after proving Euler\'s identity during a lecture, stated that the identity \\"is absolutely paradoxical; we cannot understand it, and we don\'t know what it means, but we have proved it, and therefore we know it must be the truth\\". A poll of readers conducted by The Mathematical Intelligencer in 1990 named Euler\'s identity as the \\"most beautiful theorem in mathematics\\". In another poll of readers that was conducted by Physics World in 2004, Euler\'s identity tied with Maxwell\'s equations (of electromagnetism) as the \\"greatest equation ever\\". At least three books in popular mathematics have been published about Euler\'s identity: Dr. Euler\'s Fabulous Formula: Cures Many Mathematical Ills, by Paul Nahin (2011) A Most Elegant Equation: Euler\'s formula and the beauty of mathematics, by David Stipp (2017) Euler\'s Pioneering Equation: The most beautiful theorem in mathematics, by Robin Wilson (2018). Explanations Imaginary exponents Fundamentally, Euler\'s identity asserts that e i \\u03c0 {\\\\displaystyle e^{i\\\\pi }} is equal to \\u22121. The expression e i \\u03c0 {\\\\displaystyle e^{i\\\\pi }} is a special case of the expression e z {\\\\displaystyle e^{z}} , where z is any complex number. In general, e z {\\\\displaystyle e^{z}} is defined for complex z by extending one of the definitions of the exponential function from real exponents to complex exponents. For example, one common definition is: e z = lim n \\u2192 \\u221e ( 1 + z n ) n . {\\\\displaystyle e^{z}=\\\\lim _{n\\\\to \\\\infty }\\\\left(1+{\\\\frac {z}{n}}\\\\right)^{n}.} Euler\'s identity therefore states that the limit, as n approaches infinity, of ( 1 + i \\u03c0 / n ) n {\\\\displaystyle (1+i\\\\pi /n)^{n}} is equal to \\u22121. This limit is illustrated in the animation to the right. Euler\'s identity is a special case of Euler\'s formula, which states that for any real number x, e i x = cos \\u2061 x + i sin \\u2061 x {\\\\displaystyle e^{ix}=\\\\cos x+i\\\\sin x} where the inputs of the trigonometric functions sine and cosine are given in radians. In particular, when x = \\u03c0, e i \\u03c0 = cos \\u2061 \\u03c0 + i sin \\u2061 \\u03c0 . {\\\\displaystyle e^{i\\\\pi }=\\\\cos \\\\pi +i\\\\sin \\\\pi .} Since cos \\u2061 \\u03c0 = \\u2212 1 {\\\\displaystyle \\\\cos \\\\pi =-1} and sin \\u2061 \\u03c0 = 0 , {\\\\displaystyle \\\\sin \\\\pi =0,} it follows that e i \\u03c0 = \\u2212 1 + 0 i , {\\\\displaystyle e^{i\\\\pi }=-1+0i,} which yields Euler\'s identity: e i \\u03c0 + 1 = 0. {\\\\displaystyle e^{i\\\\pi }+1=0.} Geometric interpretation Any complex number z = x + i y {\\\\displaystyle z=x+iy} can be represented by the point ( x , y ) {\\\\displaystyle (x,y)} on the complex plane. This point can also be represented in polar coordinates as ( r , \\u03b8 ) {\\\\displaystyle (r,\\\\theta )} , where r is the absolute value of z (distance from the origin), and \\u03b8 {\\\\displaystyle \\\\theta } is the argument of z (angle counterclockwise from the positive x-axis). By the definitions of sine and cosine, this point has cartesian coordinates of ( r cos \\u2061 \\u03b8 , r sin \\u2061 \\u03b8 ) {\\\\displaystyle (r\\\\cos \\\\theta ,r\\\\sin \\\\theta )} , implying that z = r ( cos \\u2061 \\u03b8 + i sin \\u2061 \\u03b8 ) {\\\\displaystyle z=r(\\\\cos \\\\theta +i\\\\sin \\\\theta )} . According to Euler\'s formula, this is equivalent to saying z = r e i \\u03b8 {\\\\displaystyle z=re^{i\\\\theta }} . Euler\'s identity says that \\u2212 1 = e i \\u03c0 {\\\\displaystyle -1=e^{i\\\\pi }} . Since e i \\u03c0 {\\\\displaystyle e^{i\\\\pi }} is r e i \\u03b8 {\\\\displaystyle re^{i\\\\theta }} for r = 1 and \\u03b8 = \\u03c0 {\\\\displaystyle \\\\theta =\\\\pi } , this can be interpreted as a fact about the number \\u22121 on the complex plane: its distance from the origin is 1, and its angle from the positive x-axis is \\u03c0 {\\\\displaystyle \\\\pi } radians. Additionally, when any complex number z is multiplied by e i \\u03b8 {\\\\displaystyle e^{i\\\\theta }} , it has the effect of rotating z counterclockwise by an angle of \\u03b8 {\\\\displaystyle \\\\theta } on the complex plane. Since multiplication by \\u22121 reflects a point across the origin, Euler\'s identity can be interpreted as saying that rotating any point \\u03c0 {\\\\displaystyle \\\\pi } radians around the origin has the same effect as reflecting the point across the origin. Similarly, setting \\u03b8 {\\\\displaystyle \\\\theta } equal to 2 \\u03c0 {\\\\displaystyle 2\\\\pi } yields the related equation e 2 \\u03c0 i = 1 , {\\\\displaystyle e^{2\\\\pi i}=1,} which can be interpreted as saying that rotating any point by one turn around the origin returns it to its original position. Generalizations Euler\'s identity is also a special case of the more general identity that the nth roots of unity, for n > 1, add up to 0: \\u2211 k = 0 n \\u2212 1 e 2 \\u03c0 i k n = 0. {\\\\displaystyle \\\\sum _{k=0}^{n-1}e^{2\\\\pi i{\\\\frac {k}{n}}}=0.} Euler\'s identity is the case where n = 2. A similar identity also applies to quaternion exponential: let {i, j, k} be the basis quaternions; then, e 1 3 ( i \\u00b1 j \\u00b1 k ) \\u03c0 + 1 = 0. {\\\\displaystyle e^{{\\\\frac {1}{\\\\sqrt {3}}}(i\\\\pm j\\\\pm k)\\\\pi }+1=0.} More generally, let q be a quaternion with a zero real part and a norm equal to 1; that is, q = a i + b j + c k , {\\\\displaystyle q=ai+bj+ck,} with a 2 + b 2 + c 2 = 1. {\\\\displaystyle a^{2}+b^{2}+c^{2}=1.} Then one has e q \\u03c0 + 1 = 0. {\\\\displaystyle e^{q\\\\pi }+1=0.} The same formula applies to octonions, with a zero real part and a norm equal to 1. These formulas are a direct generalization of Euler\'s identity, since i {\\\\displaystyle i} and \\u2212 i {\\\\displaystyle -i} are the only complex numbers with a zero real part and a norm (absolute value) equal to 1. History While Euler\'s identity is a direct result of Euler\'s formula, published in his monumental work of mathematical analysis in 1748, Introductio in analysin infinitorum, it is questionable whether the particular concept of linking five fundamental constants in a compact form can be attributed to Euler himself, as he may never have expressed it. Robin Wilson states the following. We\'ve seen how it [Euler\'s identity] can easily be deduced from results of Johann Bernoulli and Roger Cotes, but that neither of them seem to have done so. Even Euler does not seem to have written it down explicitly \\u2013 and certainly it doesn\'t appear in any of his publications \\u2013 though he must surely have realized that it follows immediately from his identity [i.e. Euler\'s formula], eix = cos x + i sin x. Moreover, it seems to be unknown who first stated the result explicitly.... Intuitive understanding of Euler\'s formula</document>"}], "role": "user"}, {"content": [{"text": "{"}], "role": "assistant"}], "model_id": "us.anthropic.claude-3-haiku-20240307-v1:0", "system": [{"text": "You are a helpful assistant.\\n    Inside the <document> tag is a text that has 1 or more topics discussed.\\n    Identify each topic and create a very brief summary for each topic.\\n    The total response should be less than 100 words.\\n    Return the topics in json format. The person or thing being discussed should be the key.\\n    Make sure the key is a string with no spaces, leading numbers, or special characters.\\n    The value should be a short description of the topic.\\n    "}]}, "created_at": "2024-11-09T00:34:46.450411", "request_id": "93b8b5e3-acc5-4109-b9c4-a82de3f145b8", "status": "RECEIVED"}}', 'attributes': {'ApproximateReceiveCount': '6', 'AWSTraceHeader': 'Root=1-672eae45-58a8d5d45f1607f81f08f968;Parent=782058a31e6461e8;Sampled=0;Lineage=1:e084563a:0', 'SentTimestamp': '1731112517972', 'SequenceNumber': '18889908878310383872', 'MessageGroupId': 'default', 'SenderId': 'AROASBV2SO4YX5ZXZ4AHG:BrRequestSmootherStack-PrioritizationLambda37BA0FF-wZtcFN9TPFJk', 'MessageDeduplicationId': '8605846340fe2632bea2f3ae0f059be8', 'ApproximateFirstReceiveTimestamp': '1731112517972'}, 'messageAttributes': {}, 'md5OfBody': 'dd0ced025e87e92fa58fa3f92578a232', 'eventSource': 'aws:sqs', 'eventSourceARN': 'arn:aws:sqs:us-east-1:141051459377:BrRequestSmootherStack-HoldNextBatchQueueF9A91014-tZOiOs2UNVTB.fifo', 'awsRegion': 'us-east-1'}]}
#     handler(e, {})