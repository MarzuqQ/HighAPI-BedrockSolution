import boto3
import json
import uuid
import logging
from datetime import datetime

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')

def process_message(message):
    """
    Processes a single message by storing it in S3 and recording metadata in DynamoDB.
    
    Creates a unique identifier for the request and stores the raw request data
    in S3 while maintaining request metadata in DynamoDB for tracking purposes.
    
    Args:
        message (dict): The message payload to process
    """
    # Generate unique ID using UUID
    request_id = str(uuid.uuid4())
    timestamp = datetime.utcnow().isoformat()
    
    try:
        # Store raw data in S3
        s3.put_object(
            Bucket='bedrock-request-calls1',
            Key=f'{request_id}.json',
            Body=json.dumps(message)
        )
        logger.info("Successfully stored request data in S3 with ID: %s", request_id)
        
        # Store metadata in DynamoDB
        table = dynamodb.Table('RequestMetadataTable3')
        table.put_item(
            Item={
                'request_id': request_id,
                'status': 'RECEIVED',
                'created_at': timestamp,
                'original_request': message
            }
        )
        logger.info("Successfully stored request metadata in DynamoDB with ID: %s", request_id)
        
    except Exception as e:
        logger.error("Error processing request %s: %s", request_id, str(e))
        raise

def handler(event, context):
    """
    Main entry point for the Lambda function that processes incoming requests.
    
    Handles both direct invocations and SQS event sources. For SQS events, 
    processes each record in the batch. For direct invocations, processes 
    the event directly.
    
    Args:
        event (dict): The event data from the Lambda trigger
        context (LambdaContext): Runtime information provided by AWS Lambda
    
    Returns:
        dict: Response object with status code
    """
    logger.debug("Received event: %s", json.dumps(event))

    # Check if the event is from SQS
    if 'Records' in event:
        for record in event['Records']:
            try:
                message = json.loads(record['body'])
            except KeyError:
                logger.error("Unexpected event structure. 'body' not found in record")
                continue
            except json.JSONDecodeError:
                logger.error("Failed to parse message body as JSON")
                continue

            # Process the message
            process_message(message)
    else:
        # For direct invocation or other event sources
        process_message(event)

    return {'statusCode': 200,
            'body': f'{event}'}

if __name__ == "__main__":
    sample_message = {
            'Records': [{
                'messageId': '016e1663-d2d9-4206-ba59-24c37f2144b8',
                'receiptHandle': 'AQEB/d66wRP53dZiFbD7e4cGbkfW7aBTMX7SzzlzA/xy3EPdRgYbjFVI4OvWq3PPnVSdh9B4M+GAYklKfS34vu5JJgvAmnjg6e+rl+TPEEvlG1+dpR70VVm+Y8sz+HEVL9IaKGUT2z+g0heV0DdEZTD3KR8Uz+RtVsRnwGNvwUZKPSEPNaJ6EDDbYD+xcXktSH1cwehkunY3zNBxa5+tEltjobcAr2Cd0SwGKRR3LPekjT7lzcCRdEDIwWIHNHxbCkRAakodONxPmWGM16uAwcAFSmkZX62RuNbDrofawsqXyFp5jV1G63+G4kvmqtoLW/+yeqkbkyqKq02rV5r1TCU5feEpZ2pHMx1erudHIsBwAV05QnS4CqAFK3ecKebxZmjZgvcxgLprZqDEK2fZoNnTvFhNbzyGfknCcttua9IR/ovdg8EA5jr524qJdvpP9M5t',
                'body': '{"model_id": "us.anthropic.claude-3-haiku-20240307-v1:0", "messages": [{"role": "user", "content": [{"text": "<document>Dianne_Cook\\n\\nDiane Cook is an American writer. Diane or Dianne Cook may also refer to: Diane Cook (photographer), American photographer Diane G. Cook, American Parkinson\'s disease advocate Diane J. Cook, American computer scientist Dianne Cook (basketball), former Australian women\'s basketball player Dianne Cook (statistician), Australian statistician\\n\\nNoSQL\\n\\nNoSQL (originally referring to \\"non-SQL\\" or \\"non-relational\\") is an approach to database design that focuses on providing a mechanism for storage and retrieval of data that is modeled in means other than the tabular relations used in relational databases. Instead of the typical tabular structure of a relational database, NoSQL databases house data within one data structure. Since this non-relational database design does not require a schema, it offers rapid scalability to manage large and typically unstructured data sets. NoSQL systems are also sometimes called \\"Not only SQL\\" to emphasize that they may support SQL-like query languages or sit alongside SQL databases in polyglot-persistent architectures. Non-relational databases have existed since the late 1960s, but the name \\"NoSQL\\" was only coined in the early 2000s, triggered by the needs of Web 2.0 companies. NoSQL databases are increasingly used in big data and real-time web applications. Motivations for this approach include simplicity of design, simpler \\"horizontal\\" scaling to clusters of machines (which is a problem for relational databases), finer control over availability, and limiting the object-relational impedance mismatch. The data structures used by NoSQL databases (e.g. key\\u2013value pair, wide column, graph, or document) are different from those used by default in relational databases, making some operations faster in NoSQL. The particular suitability of a given NoSQL database depends on the problem it must solve. Sometimes the data structures used by NoSQL databases are also viewed as \\"more flexible\\" than relational database tables. Many NoSQL stores compromise consistency (in the sense of the CAP theorem) in favor of availability, partition tolerance, and speed. Barriers to the greater adoption of NoSQL stores include the use of low-level query languages (instead of SQL, for instance), lack of ability to perform ad hoc joins across tables, lack of standardized interfaces, and huge previous investments in existing relational databases. Most NoSQL stores lack true ACID transactions, although a few databases have made them central to their designs. Instead, most NoSQL databases offer a concept of \\"eventual consistency\\", in which database changes are propagated to all nodes \\"eventually\\" (typically within milliseconds), so queries for data might not return updated data immediately or might result in reading data that is not accurate, a problem known as stale read. Additionally, some NoSQL systems may exhibit lost writes and other forms of data loss. Some NoSQL systems provide concepts such as write-ahead logging to avoid data loss. For distributed transaction processing across multiple databases, data consistency is an even bigger challenge that is difficult for both NoSQL and relational databases. Relational databases \\"do not allow referential integrity constraints to span databases\\". Few systems maintain both ACID transactions and X/Open XA standards for distributed transaction processing. Interactive relational databases share conformational relay analysis techniques as a common feature. Limitations within the interface environment are overcome using semantic virtualization protocols, such that NoSQL services are accessible to most operating systems. History The term NoSQL was used by Carlo Strozzi in 1998 to name his lightweight Strozzi NoSQL open-source relational database that did not expose the standard Structured Query Language (SQL) interface, but was still relational. His NoSQL RDBMS is distinct from the around-2009 general concept of NoSQL databases. Strozzi suggests that, because the current NoSQL movement \\"departs from the relational model altogether, it should therefore have been called more appropriately \'NoREL\'\\", referring to \\"not relational\\". Johan Oskarsson, then a developer at Last.fm, reintroduced the term NoSQL in early 2009 when he organized an event to discuss \\"open-source distributed, non-relational databases\\". The name attempted to label the emergence of an increasing number of non-relational, distributed data stores, including open source clones of Google\'s Bigtable/MapReduce and Amazon\'s DynamoDB. Types and examples There are various ways to classify NoSQL databases, with different categories and subcategories, some of which overlap. What follows is a non-exhaustive classification by data model, with examples: Key\\u2013value store Key\\u2013value (KV) stores use the associative array (also called a map or dictionary) as their fundamental data model. In this model, data is represented as a collection of key\\u2013value pairs, such that each possible key appears at most once in the collection. The key\\u2013value model is one of the simplest non-trivial data models, and richer data models are often implemented as an extension of it. The key\\u2013value model can be extended to a discretely ordered model that maintains keys in lexicographic order. This extension is computationally powerful, in that it can efficiently retrieve selective key ranges. Key\\u2013value stores can use consistency models ranging from eventual consistency to serializability. Some databases support ordering of keys. There are various hardware implementations, and some users store data in memory (RAM), while others on solid-state drives (SSD) or rotating disks (aka hard disk drive (HDD)). Document store The central concept of a document store is that of a \\"document\\". While the details of this definition differ among document-oriented databases, they all assume that documents encapsulate and encode data (or information) in some standard formats or encodings. Encodings in use include XML, YAML, and JSON and binary forms like BSON. Documents are addressed in the database via a unique key that represents that document. Another defining characteristic of a document-oriented database is an API or query language to retrieve documents based on their contents. Different implementations offer different ways of organizing and/or grouping documents: Collections Tags Non-visible metadata Directory hierarchies Compared to relational databases, collections could be considered analogous to tables and documents analogous to records. But they are different \\u2013 every record in a table has the same sequence of fields, while documents in a collection may have fields that are completely different. Graph Graph databases are designed for data whose relations are well represented as a graph consisting of elements connected by a finite number of relations. Examples of data include social relations, public transport links, road maps, network topologies, etc. Graph databases and their query language Performance The performance of NoSQL databases is usually evaluated using the metric of throughput, which is measured as operations/second. Performance evaluation must pay attention to the right benchmarks such as production configurations, parameters of the databases, anticipated data volume, and concurrent user workloads. Ben Scofield rated different categories of NoSQL databases as follows: Performance and scalability comparisons are most commonly done using the YCSB benchmark. Handling relational data Since most NoSQL databases lack ability for joins in queries, the database schema generally needs to be designed differently. There are three main techniques for handling relational data in a NoSQL database. (See table Join and ACID Support for NoSQL databases that support joins.) Multiple queries Instead of retrieving all the data with one query, it is common to do several queries to get the desired data. NoSQL queries are often faster than traditional SQL queries so the cost of additional queries may be acceptable. If an excessive number of queries would be necessary, one of the other two approaches is more appropriate. Caching, replication and non-normalized data Instead of only storing foreign keys, it is common to store actual foreign values along with the model\'s data. For example, each blog comment might include the username in addition to a user id, thus providing easy access to the username without requiring another lookup. When a username changes however, this will now need to be changed in many places in the database. Thus this approach works better when reads are much more common than writes. Nesting data With document databases like MongoDB it is common to put more data in a smaller number of collections. For example, in a blogging application, one might choose to store comments within the blog post document so that with a single retrieval one gets all the comments. Thus in this approach a single document contains all the data you need for a specific task. ACID and join support A database is marked as supporting ACID properties (Atomicity, Consistency, Isolation, Durability) or join operations if the documentation for the database makes that claim. However, this doesn\'t necessarily mean that the capability is fully supported in a manner similar to most SQL databases.\\n\\nJohn_Saul\\n\\nJohn Saul (born February 25, 1942) is an American author of suspense and horror novels. Most of his books have appeared on the New York Times Best Seller list. Biography Born in Pasadena, Saul grew up in Whittier, California, and graduated from Whittier High School in 1959. He went on to several colleges, including Cerritos College, Antioch College, San Francisco State University and Montana State University, variously majoring in anthropology, liberal arts and theater, but remains degree-less. After leaving college, Saul decided to become a writer, and spent 15 years working in various jobs while learning his craft. Prior to the start of his bestselling thriller career, Saul had around 10 books published under pen names, the first of which he wrote in one weekend after unexpectedly losing his job. His first book sale earned him just $200. Today he has over 60 million books in print. In 1976, Dell Publishing contacted him about his writing a psychological thriller. The resulting novel, Suffer the Children, appeared on all the bestseller lists in the United States and reached the number one spot in Canada. His 1979 novel Cry for the Strangers was made into a 1982 TV movie starring Patrick Duffy and Cindy Pickett. In addition to his novels, Saul has had several one-act plays produced in Los Angeles and Seattle. Saul lives part-time in the Pacific Northwest, both in Seattle and in the San Juan Islands, and has a residence on the Big Island of Hawaii. Saul is openly gay. He lives with his partner of almost 50 years (since 1975) who has collaborated on several of his novels. He is a frequent speaker at the Maui Writers\' Conference. Works Novels References External links http://www.johnsaul.com/ John Saul at the Internet Speculative Fiction Database</document>"}]}], "system": [{"text": "You are a helpful assistant.\\n    Inside the <document> tag is a text that has 1 or more topics discussed.\\n    Identify each topic and create a very brief summary for each topic.\\n    The total response should be less than 100 words.\\n    Return the topics in json format. The person or thing being discussed should be the key.\\n    Make sure the key is a string with no spaces, leading numbers, or special characters.\\n    The value should be a short description of the topic.\\n    "}]}',
                'attributes': {
                    'ApproximateReceiveCount': '1',
                    'SentTimestamp': '1730993557695',
                    'SenderId': 'AIDASBV2SO4Y27QAVNXB6',
                    'ApproximateFirstReceiveTimestamp': '1730993557696'
                },
                'messageAttributes': {},
                'md5OfBody': 'f66dbeffd0df307116195d0d2cc38a17',
                'eventSource': 'aws:sqs',
                'eventSourceARN': 'arn:aws:sqs:us-east-1:141051459377:BrRequestSmootherStack-InputQueueFD90041C-vYp6YqumWq0m',
                'awsRegion': 'us-east-1'
            }]
        }
    handler(sample_message, {})

