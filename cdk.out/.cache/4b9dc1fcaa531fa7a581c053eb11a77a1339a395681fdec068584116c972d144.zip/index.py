import boto3
import json
import uuid
from datetime import datetime

s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')

def lambda_handler(event, context):
    print("Received event:", json.dumps(event))  # Log the entire event for debugging

    # Check if the event is from SQS
    if 'Records' in event:
        for record in event['Records']:
            # For SQS events, the body is in record['body']
            try:
                message = json.loads(record['body'])
            except KeyError:
                print("Unexpected event structure. 'body' not found in record.")
                continue
            except json.JSONDecodeError:
                print("Failed to parse message body as JSON.")
                continue

            # Process the message
            process_message(message)
    else:
        # For direct invocation or other event sources
        process_message(event)

    return {'statusCode': 200}

def process_message(message):
    # Generate unique ID
    request_id = str(uuid.uuid4())
    
    # Get current timestamp
    timestamp = datetime.utcnow().isoformat()
    
    # Store raw data in S3
    s3.put_object(
        Bucket='bedrock-request-calls1',
        Key=f'{request_id}.json',
        Body=json.dumps(message)
    )
    
    # Store metadata in DynamoDB
    table = dynamodb.Table('RequestMetadataTable3')
    table.put_item(
        Item={
            'request_id': request_id,
            'status': 'RECEIVED',
            'created_at': timestamp,
            'original_request': message  # Store the original request in DynamoDB
        }
    )
    
    print(f"Processed request {request_id}, created at {timestamp}")
