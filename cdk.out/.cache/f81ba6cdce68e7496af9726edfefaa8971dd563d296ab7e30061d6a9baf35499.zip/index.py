import boto3
import json
import random
import logging
from datetime import datetime, timedelta
import os
import hashlib
from botocore.exceptions import ClientError
from decimal import Decimal

# Logger setup
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
sqs_client = boto3.client('sqs')
dynamodb = boto3.resource('dynamodb')
service_quotas = boto3.client('service-quotas', region_name=os.environ.get("REGION", 'us-east-1'))

AVERAGE_REQUEST_DURATION_IN_SECONDS = 5

# Enhance models dictionary with more metadata
models = {
    'anthropic_claude_3_haiku': {
        'id': 'anthropic.claude-3-haiku-20240307-v1:0',
        'name': 'Anthropic Claude 3 Haiku',
        'rpm_quota_code': "L-2DC80978",
        'tpm_quota_code': "L-8CE99163"
    }
}

# Custom JSON encoder to handle Decimal types
class DecimalEncoder(json.JSONEncoder):
    """
    Custom JSON encoder for handling Decimal types.
    
    Extends the standard JSON encoder to properly serialize Decimal objects
    by converting them to float values.
    """
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super(DecimalEncoder, self).default(obj)

def get_service_quotas(region):
    """
    Retrieves AWS Bedrock service quotas for specified models in the given region.
    
    Args:
        region (str): AWS region to query quotas from
        
    Returns:
        dict: Dictionary containing RPM and TPM quotas for each model
              Format: {
                  'model_name': {
                      'RPM': float,
                      'RPM_CODE': str,
                      'TPM': float,
                      'TPM_CODE': str
                  }
              }
              
    Raises:
        ValueError: If region is not specified
        ClientError: If AWS API call fails
        Exception: For unexpected errors
    """
    # Add input validation
    if not region:
        raise ValueError("Region must be specified")
    
    logger.debug(f'Getting service quotas for region: {region}')
    quotas = {}
    try:
        # Get quotas for each model using their specific quota codes
        logger.debug(f"Starting quota retrieval for models: {list(models.keys())}")
        for model_name, model_info in models.items():
            logger.debug(f"Getting quotas for model: {model_name}")
            logger.debug(f"Model info: {json.dumps(model_info)}")
            quotas[model_name] = {}
            
            # Get RPM quota
            logger.debug(f"Getting RPM quota with code: {model_info['rpm_quota_code']}")
            rpm_response = service_quotas.get_service_quota(
                ServiceCode='bedrock',
                QuotaCode=model_info['rpm_quota_code']
            )
            logger.debug(f"RPM quota response: {json.dumps(rpm_response)}")
            quotas[model_name]['RPM'] = rpm_response['Quota']['Value']
            quotas[model_name]['RPM_CODE'] = model_info['rpm_quota_code']
            
            # Get TPM quota  
            logger.debug(f"Getting TPM quota with code: {model_info['tpm_quota_code']}")
            tpm_response = service_quotas.get_service_quota(
                ServiceCode='bedrock',
                QuotaCode=model_info['tpm_quota_code']
            )
            logger.debug(f"TPM quota response: {json.dumps(tpm_response)}")
            quotas[model_name]['TPM'] = tpm_response['Quota']['Value']
            quotas[model_name]['TPM_CODE'] = model_info['tpm_quota_code']

        logger.debug(f"Retrieved quotas: {json.dumps(quotas, cls=DecimalEncoder)}")
        return quotas

    except ClientError as e:
        logger.error(f"AWS ClientError retrieving service quotas: {str(e)}")
        # Return default values instead of empty dict on error
        return {model: {'RPM': info['default_rpm'], 'TPM': info['default_tpm']} 
                for model, info in models.items()}
    except Exception as e:
        logger.error(f"Unexpected error retrieving service quotas: {str(e)}")
        raise

def send_message_to_sqs(sqs_queue_url, request, sent_count):
    """
    Sends a message to SQS queue with deduplication handling.
    
    Args:
        sqs_queue_url (str): URL of the SQS queue
        request (dict): Request data to be sent
        sent_count (int): Current count of successfully sent messages
        
    Returns:
        int: Updated count of successfully sent messages
        
    Raises:
        ClientError: If SQS API call fails
        Exception: For unexpected errors
    """
    try:
        request_id = request['request_id']
        message_body = json.dumps({
            'request_id': request_id,
            'timestamp': datetime.utcnow().isoformat(),
            'data': request
        }, cls=DecimalEncoder)
        
        deduplication_id = hashlib.md5(request_id.encode()).hexdigest()

        response = sqs_client.send_message(
            QueueUrl=sqs_queue_url,
            MessageBody=message_body,
            MessageGroupId=os.environ.get("DEFAULT_MESSAGE_GROUP_ID"),
            MessageDeduplicationId=deduplication_id
        )
        logger.debug(f"Sent message to SQS: {response['MessageId']} for request_id: {request_id}")
        return sent_count + 1
    except ClientError as e:
        if e.response['Error']['Code'] == 'AWS.SimpleQueueService.DuplicateMessageContent':
            logger.info(f"Duplicate message detected for request_id: {request_id}. Skipping.")
            return sent_count
        raise
    except Exception as e:
        logger.error(f"Failed to send message to SQS: {str(e)}")
        raise

def check_conditions(event, context):
    """
    Checks if conditions are met to process the next batch of requests.
    
    Args:
        event (dict): Lambda event object
        context (obj): Lambda context object
        
    Returns:
        bool: True if conditions are met (queue depth < 100 and table has items),
              False otherwise
        
    Raises:
        ClientError: If AWS API calls fail
    """
    sqs = boto3.client('sqs')
    dynamodb = boto3.client('dynamodb')
    
    try:
        # Check SQS queue depth
        queue_attrs = sqs.get_queue_attributes(
            QueueUrl=os.environ['HOLD_NEXT_BATCH_QUEUE_URL'],
            AttributeNames=['ApproximateNumberOfMessages']
        )
        queue_depth = int(queue_attrs['Attributes']['ApproximateNumberOfMessages'])
        
        # Check DynamoDB table count
        table_count = dynamodb.scan(
            TableName=os.environ['DYNAMO_TABLE'],
            Select='COUNT'
        )['Count']
        
        return queue_depth < 100 and table_count > 0
    except ClientError as e:
        logger.error(f"Error checking conditions: {str(e)}")
        return False

def handler(event, context):
    """
    Main Lambda handler for request prioritization and queue management.
    
    Checks queue depth and processes pending requests based on service quotas
    and prioritization rules. Sends prioritized requests to SQS queue for
    processing.
    
    Args:
        event (dict): Lambda event object
        context (obj): Lambda context object
        
    Returns:
        dict: Response object with status code and message
              Format: {
                  'statusCode': int,
                  'body': str or dict
              }
        
    Raises:
        ValueError: If required environment variables are missing
        Exception: For unexpected errors
    """
    # Check conditions before processing
    if not check_conditions(event, context):
        logger.info("Conditions not met, skipping processing")
        return {
            'statusCode': 200,
            'body': 'Conditions not met for processing'
        }
    
    logger.debug(f"Received event: {json.dumps(event)}")
    # Read environment variables
    sqs_queue_url = os.environ.get("HOLD_NEXT_BATCH_QUEUE_URL")
    table_name = os.environ.get("DYNAMO_TABLE")
    logger.info(f"Using SQS Queue URL: {sqs_queue_url}")
    logger.info(f"Using DynamoDB Table: {table_name}")
    
    sent_count = 0  # Initialize sent_count here
    
    try:
        # Validate required environment variables
        if not sqs_queue_url or not table_name:
            raise ValueError("Missing required environment variables: SQS_QUEUE_URL or DYNAMO_TABLE")

        # Monitor the SQS Queue
        queue_attributes = sqs_client.get_queue_attributes(
            QueueUrl=sqs_queue_url,
            AttributeNames=['ApproximateNumberOfMessages']
        )
        message_count = int(queue_attributes['Attributes']['ApproximateNumberOfMessages'])
        logger.info(f"Current SQS Queue message count: {message_count}")

        # If the queue has less than 100 messages, reprioritize and send more to the queue
        if message_count < 100:
            table = dynamodb.Table(table_name)
            logger.debug("Scanning DynamoDB for items with blank request_status")
            
            # Fetch requests with blank request_status
            scan_params = {
                'FilterExpression': 'attribute_not_exists(request_status) OR request_status = :empty_status',
                'ExpressionAttributeValues': {
                    ':empty_status': ''
                }
            }
            logger.debug(f"Scan parameters: {json.dumps(scan_params)}")
            
            response = table.scan(**scan_params)
            logger.debug(f"Scan response: {json.dumps(response, cls=DecimalEncoder)}")
            
            logger.info(f"Found {len(response['Items'])} requests for prioritization")

            if not response['Items']:
                logger.warning("No items found with blank request_status")
                return {
                    "statusCode": 200,
                    "body": json.dumps({"message": "No items to prioritize"})
                }

            # Apply prioritization logic - oldest first
            prioritized_requests = sorted(response['Items'], key=lambda x: x.get('created_at', ''))
            logger.debug(f"Prioritized requests: {json.dumps(prioritized_requests, cls=DecimalEncoder)}")

            # Check Bedrock service quotas
            quotas = get_service_quotas(os.environ.get("REGION"))
            logger.debug(f"Retrieved quotas: {json.dumps(quotas, cls=DecimalEncoder)}")
            
            concurrent_requests = int(quotas.get('anthropic_claude_3_haiku', {}).get('RPM')/int(os.environ.get("AVERAGE_REQUEST_DURATION_IN_SECONDS", AVERAGE_REQUEST_DURATION_IN_SECONDS)))
            max_requests = min(concurrent_requests*int(os.environ.get("MINUTES_TO_PROCESS", 5)), len(prioritized_requests))
            logger.info(f"Will attempt to send {max_requests} requests to SQS")
            
            # Use the extracted send_message_to_sqs function
            for request in prioritized_requests[:max_requests]:
                sent_count = send_message_to_sqs(sqs_queue_url, request, sent_count)

            logger.info(f"Successfully sent {sent_count} messages to SQS")
        else:
            logger.info("Queue has sufficient messages, no prioritization needed")

    except Exception as e:
        logger.error(f"An error occurred: {str(e)}")
        raise

    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": "Prioritization and quota check complete" if sent_count > 0 else "No messages sent",
            "messages_sent": sent_count
        })
    }
