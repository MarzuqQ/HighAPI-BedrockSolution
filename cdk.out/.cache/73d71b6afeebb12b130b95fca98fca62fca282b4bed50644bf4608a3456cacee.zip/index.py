import json
import boto3
import os
from botocore.exceptions import ClientError
from datetime import datetime
import logging

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
s3 = boto3.client('s3')
sqs = boto3.client('sqs')
dynamodb = boto3.resource('dynamodb')
bedrock = boto3.client('bedrock-runtime')


def update_dynamodb_error(table, request_id, error_message):
    table.update_item(
        Key={'request_id': request_id},
        UpdateExpression="SET request_status = :status, updated_at = :time, error_message = :error",
        ExpressionAttributeValues={
            ':status': 'FAILED',
            ':time': datetime.utcnow().isoformat(),
            ':error': error_message
        }
    )
    logger.info(f"Updated DynamoDB for request {request_id}: status set to FAILED")

def get_request_data(s3_client, bucket, request_id):
    """Retrieve and validate request data from S3"""
    try:
        response = s3_client.get_object(Bucket=bucket, Key=f'{request_id}.json')
        request_data_str = response['Body'].read().decode('utf-8')
        request_data = json.loads(request_data_str)
        logger.info(f"Request data for {request_id}: {json.dumps(request_data)}")
        return request_data
    except json.JSONDecodeError:
        raise ValueError(f"Invalid JSON format for request {request_id}")
    except Exception as e:
        raise ValueError(f"Failed to retrieve request data: {str(e)}")

def update_request_status(table, request_id, status):
    """Update request status in DynamoDB"""
    table.update_item(
        Key={'request_id': request_id},
        UpdateExpression="SET request_status = :status, updated_at = :time",
        ExpressionAttributeValues={
            ':status': status,
            ':time': datetime.utcnow().isoformat()
        }
    )
    logger.info(f"Updated DynamoDB for request {request_id}: status set to {status}")

def prepare_bedrock_params(request_data):
    """Extract and validate Bedrock parameters"""
    messages = request_data.get('messages', [])
    model_id = request_data.get('model_id')
    system = request_data.get('system', [])

    if not (messages and model_id):
        raise ValueError("Missing required fields: 'messages' or 'model_id'")

    params = {
        "modelId": model_id,
        "messages": messages,
    }
    
    if system:
        params["system"] = system
        
    return params

def process_bedrock_response(response):
    """Process and validate Bedrock response"""
    if 'output' not in response or 'message' not in response['output']:
        raise ValueError("Invalid response structure from Bedrock API")

    message_content = response['output']['message']
    
    if 'content' not in message_content or not message_content['content']:
        raise ValueError("No content in message response")

    completion = message_content['content'][0].get('text', "No content returned")
    details = message_content['content'][0].get('details', {})

    try:
        return json.loads('{' + completion), response['metrics'], response['usage'] # the '{' is needed to keep claude from being chatty
    except json.JSONDecodeError:
        logger.warning("Failed to parse completion as JSON")
        return completion

def process_record(record, s3, dynamodb_table, bedrock_client, bucket):
    """Process a single SQS record"""
    message = json.loads(record['body'])
    request_id = message['request_id']
    
    try:
        # Get and validate request data
        request_data = get_request_data(s3, bucket, request_id)
        
        # Update status to in progress
        update_request_status(dynamodb_table, request_id, 'IN_PROGRESS')
        
        # Prepare and make Bedrock call
        params = prepare_bedrock_params(request_data)
        bedrock_response = bedrock_client.converse(**params)
        logger.debug(f"Raw Bedrock response: {bedrock_response}")
        
        # Process response
        result, metrics, usage = process_bedrock_response(bedrock_response)
        logger.info(f"Latency: {metrics['latencyMs']}")
        return request_id, result, metrics, usage
    except Exception as e:
        logger.error(f"Unexpected error processing request {request_id}: {str(e)}", exc_info=True)
        update_dynamodb_error(dynamodb_table, request_id, str(e))
        raise

def handler(event, context):
    # Environment variables
    S3_BUCKET = os.environ['S3_BUCKET_NAME']
    DYNAMODB_TABLE = os.environ['DYNAMODB_TABLE_NAME']
    RESULTS_QUEUE_URL = os.environ['RESULTS_QUEUE_URL']

    logger.debug(f"Jared practice Event: {event}")
    for record in event['Records']:
        try:
            # Process the record
            request_id, result, metrics, usage = process_record(record, s3, dynamodb.Table(DYNAMODB_TABLE), bedrock, S3_BUCKET)
            
            # Prepare and send SQS message
            sqs_message = {
                'request_id': request_id,
                'original_request': result,
                'result': result,
                'metrics': metrics,
                'usage': usage
            }

            sqs_response = sqs.send_message(
                QueueUrl=RESULTS_QUEUE_URL,
                MessageBody=json.dumps(sqs_message) 
            )
            logger.info(f"Message sent to SQS. MessageId: {sqs_response['MessageId']}")

            # Update DynamoDB to mark success
            update_request_status(dynamodb.Table(DYNAMODB_TABLE), request_id, 'COMPLETED')
            
        except Exception as e:
            logger.error(f"Unexpected error processing request {request_id}: {str(e)}", exc_info=True)
            update_dynamodb_error(dynamodb.Table(DYNAMODB_TABLE), request_id, str(e))
            raise
        
    return {
        'statusCode': 200,
        'body': json.dumps(f'Processing complete for {request_id}')
    }


# if __name__ == "__main__":
#     os.environ['S3_BUCKET_NAME'] = 'brrequestsmootherstack-bedrockcallsbucket5aed0cf9-flxvjkwbkxl4'
#     os.environ['DYNAMODB_TABLE_NAME'] = 'BrRequestSmootherStack-RequestsTable419243C7-1IG49OBTTYD64'
#     os.environ['RESULTS_QUEUE_URL'] = 'https://sqs.us-east-1.amazonaws.com/141051459377/BrRequestSmootherStack-BedrockResultsQueue64EE975B-kc8aot8jIcmC'
#     e = {'Records': [{'messageId': 'd54c3a0f-16c1-4fa7-8c44-ccf3d99f578a', 'receiptHandle': 'AQEB81zMi0bQo3wtlY+5jNDkNRKi+25go0NjIgQtsDs2/Q4V9hWBW7obZKOAdEDu2d2m5As7X6QM3LiXdfPG/ACLR7VpAK1YThS/k/PVGxFr7bD9TwP0XscIfmDAEmMc/qAQAZuES1tZwR5S31L8lrSaaINYGDvMeIHA7TWCc6tjTOuyYONMCbXJ3lKU2U0Sg/J4vrlESb30K6JuwvI75wXeXz86s5uy31up7CwDNQYM+g9zAaKQ95BIzKEeyEloUAi/KJ/cRBUoZXiY2hxZetnyaOejDZ2/PVrXxE+mGYWfk11U0W+Y+lHjPrwV690iQFWYfAaxiUbkgyh/0lMSfdc43VFRB2PEb0FnK4xTT/UL0Qs=', 'body': '{"request_id": "2f898747-9bc2-4c33-8f57-4c841fc5a62b", "timestamp": "2024-11-08T21:52:18.615281", "data": {"original_request": {"messages": [{"content": [{"text": "<document>Hadley_Wickham\\n\\nHadley Alexander Wickham (born 14 October 1979) is a New Zealand statistician known for his work on open-source software for the R statistical programming environment. He is the chief scientist at Posit PBC and an adjunct professor of statistics at the University of Auckland, Stanford University, and Rice University. His work includes the data visualisation system ggplot2 and the tidyverse, a collection of R packages for data science based on the concept of tidy data. Education and career Wickham was born in Hamilton, New Zealand. He received a Bachelors degree in Human Biology and a masters degree in statistics at the University of Auckland in 1999\\u20132004 and his PhD at Iowa State University in 2008 supervised by Di Cook and Heike Hofmann. He is the chief scientist at Posit PBC (formerly RStudio PBC) and an adjunct professor of statistics at the University of Auckland, Stanford University, and Rice University. Wickham is a prominent and active member of the R user community and has developed several notable and widely used packages including ggplot2, plyr, dplyr and reshape2. Wickham\'s data analysis packages for R are collectively known as the tidyverse. According to Wickham\'s tidy data approach, each variable should be a column, each observation should be a row, and each type of observational unit should be a table. Honors and awards In 2006 he was awarded the John Chambers Award for Statistical Computing for his work developing tools for data reshaping and visualisation. Wickham was named a Fellow by the American Statistical Association in 2015 for \\"pivotal contributions to statistical practice through innovative and pioneering research in statistical graphics and computing\\". Wickham was awarded the international COPSS Presidents\' Award in 2019 for \\"influential work in statistical computing, visualisation, graphics, and data analysis\\" including \\"making statistical thinking and computing accessible to a large audience\\". Personal life Wickham\'s sister Charlotte Wickham is also a statistician. Publications Wickham\'s publications include: Wickham, Hadley; Grolemund, Garrett (2017). R for Data Science : Import, Tidy, Transform, Visualize, and Model Data. Sebastopol, CA: O\'Reilly Media. ISBN 978-1491910399. OCLC 968213225. Wickham, Hadley (2015). R Packages. Sebastopol, CA: O\'Reilly Media, Inc. ISBN 978-1491910597. Wickham, Hadley (2014). Advanced R. New York: Chapman & Hall/CRC The R Series. ISBN 978-1466586963. Wickham, Hadley (2011). \\"The split-apply-combine strategy for data analysis\\". Journal of Statistical Software. 40 (1): 1\\u201329. doi:10.18637/jss.v040.i01. Wickham, Hadley (2010). \\"A layered grammar of graphics\\". Journal of Computational and Graphical Statistics. 19 (1): 3\\u201328. doi:10.1198/jcgs.2009.07098. S2CID 58971746. Wickham, Hadley (2010). \\"stringr: modern, consistent string processing\\". The R Journal. 2 (2): 3\\u201328. doi:10.32614/RJ-2010-012. Wickham, Hadley (2009). ggplot2: Elegant Graphics for Data Analysis (Use R!). New York: Springer. ISBN 978-0387981406. Wickham, Hadley (2007). \\"Reshaping data with the reshape package\\". Journal of Statistical Software. 21 (12): 1\\u201320. doi:10.18637/jss.v021.i12.\\n\\nJohn_Saul\\n\\nJohn Saul (born February 25, 1942) is an American author of suspense and horror novels. Most of his books have appeared on the New York Times Best Seller list. Biography Born in Pasadena, Saul grew up in Whittier, California, and graduated from Whittier High School in 1959. He went on to several colleges, including Cerritos College, Antioch College, San Francisco State University and Montana State University, variously majoring in anthropology, liberal arts and theater, but remains degree-less. After leaving college, Saul decided to become a writer, and spent 15 years working in various jobs while learning his craft. Prior to the start of his bestselling thriller career, Saul had around 10 books published under pen names, the first of which he wrote in one weekend after unexpectedly losing his job. His first book sale earned him just $200. Today he has over 60 million books in print. In 1976, Dell Publishing contacted him about his writing a psychological thriller. The resulting novel, Suffer the Children, appeared on all the bestseller lists in the United States and reached the number one spot in Canada. His 1979 novel Cry for the Strangers was made into a 1982 TV movie starring Patrick Duffy and Cindy Pickett. In addition to his novels, Saul has had several one-act plays produced in Los Angeles and Seattle. Saul lives part-time in the Pacific Northwest, both in Seattle and in the San Juan Islands, and has a residence on the Big Island of Hawaii. Saul is openly gay. He lives with his partner of almost 50 years (since 1975) who has collaborated on several of his novels. He is a frequent speaker at the Maui Writers\' Conference. Works Novels References External links http://www.johnsaul.com/ John Saul at the Internet Speculative Fiction Database\\n\\nTerry_Speed\\n\\nTerence Paul \\"Terry\\" Speed (born 14 March 1943 in Victor Harbor, South Australia), FAA FRS is an Australian statistician. A senior principal research scientist at the Walter and Eliza Hall Institute of Medical Research, he is known for his contributions to the analysis of variance and bioinformatics, and in particular to the analysis of microarray data. Early life and education Terry Speed was born in Victor Harbor, in South Australia, and grew up in Melbourne. In 1961, he started a joint degree in medicine and science at the University of Melbourne, but later focussed on science only, obtaining a honours degree in mathematics and statistics in 1964. Speed obtained a Ph.D. from Monash University in 1968 with a thesis titled Some topics in the theory of distributive lattices under the supervision of Peter D. Finch. Career After his PhD, Terry Speed took a lecturing position in Sheffield (United Kingdom), at the Manchester-Sheffield School of Probability and Statistics. In 1974, he returned to Australia, becoming assistant professor at the University of Western Australia, heading the statisticians in the department of mathematics. He then became professor in 1975 and head of department in 1982. In 1984, Terry Speed became chief of the division of mathematics and statistics at CSIRO, the Commonwealth Scientific and Industrial Research Organisation. After a two month visit in the department of statistics at the University of California, Berkeley in 1984, he applied for a permanent position and became a tenured professor there in 1987. In 1996, Suzanne Cory, director of the Walter and Eliza Hall Institute of Medical Research (WEHI), in Melbourne and former high-school classmate of Speed, invited him to start a bioinformatics group at the institute. Starting in 1997, he shared his time between the two institutions. In 2009, he retired from the University of California, Berkeley, while keeping academic collaborations with the university, including the supervision of PhD students and postdocs. He started working full time at WEHI, where he was head of the Bioinformatics division until 31 August 2014, and has remained a laboratory head since then. He also served on the Mathematical Sciences jury for the Infosys Prize in 2009 and 2010. In 2016, a former colleague and a former post-doctoral researcher from the University of California, Berkeley, filed a complaint of sexual harassment against Speed, with the allegedly infringing behavior occurring in 2002. Speed has supervised at least 72 research students. Notable work Terry Speed has contributed to a wide range of subjects, including distributive lattices, ring theory, analysis of variance and bioinformatics, and in particular to the analysis of microarray data. Expert witness Speed was an expert witness for the defense of O.J. Simpson at the trial for the O. J. Simpson murder case, as well as an expert witness in the Imanishi-Kari case, an affair of alleged scientific misconduct which involved biologist David Baltimore. Much earlier in his career, he was an expert defence witness in the 1966 trial of Ronald Ryan, the last person executed in Australia; however, his evidence that Ryan must have been at least 2.55 metres tall (he was only 1.73 metres) to fire the fatal shot failed to sway the jury. Awards and honours In 1989 Speed was elected as a Fellow of the American Statistical Association. Speed was president of the Institute of Mathematical Statistics in 2004. In 2002, he received the Pitman medal. In 2009 he was awarded a NHMRC Australia Fellowship. On 30 October 2013, he received the Australian Prime Minister\'s Prize for Science. Speed was elected a Fellow of the Royal Society (FRS) of London in 2013. His nomination reads: Speed is regarded internationally as THE expert on the analysis of microarray data. This results partly from the sheer ingenuity of his work, and in part it is due to his commitment to working closely with biomedical scientists, enabling him to appreciate first-hand the biological challenges and the consequent requirements of new methodology. Microarrays are now being replaced by short-read DNA sequencing, but Speed continues to contribute new ideas for the new technology. At other time in his career, Speed has made seminal contributions to bioinformatics, statistical genetics, the analysis of designed experiments, graphical models and Bayes networks. Personal life Speed married Freda Elizabeth (Sally) Pollard in 1964.</document>"}], "role": "user"}, {"content": [{"text": "{"}], "role": "assistant"}], "model_id": "us.anthropic.claude-3-haiku-20240307-v1:0", "system": [{"text": "You are a helpful assistant.\\n    Inside the <document> tag is a text that has 1 or more topics discussed.\\n    Identify each topic and create a very brief summary for each topic.\\n    The total response should be less than 100 words.\\n    Return the topics in json format. The person or thing being discussed should be the key.\\n    Make sure the key is a string with no spaces, leading numbers, or special characters.\\n    The value should be a short description of the topic.\\n    "}]}, "created_at": "2024-11-08T21:51:50.558945", "request_id": "2f898747-9bc2-4c33-8f57-4c841fc5a62b", "status": "RECEIVED"}}', 'attributes': {'ApproximateReceiveCount': '1', 'AWSTraceHeader': 'Root=1-672e8811-608a31a032ee65d2310bcbff;Parent=6bf9ff9e845310d9;Sampled=0;Lineage=1:e084563a:0', 'SentTimestamp': '1731102738622', 'SequenceNumber': '18889906374796783616', 'MessageGroupId': 'default', 'SenderId': 'AROASBV2SO4YX5ZXZ4AHG:BrRequestSmootherStack-PrioritizationLambda37BA0FF-wZtcFN9TPFJk', 'MessageDeduplicationId': '5d4a01119484e5621ae0943865a14dd0', 'ApproximateFirstReceiveTimestamp': '1731102794592'}, 'messageAttributes': {}, 'md5OfBody': 'b4478d013dd8c583679b7d9743d498a9', 'eventSource': 'aws:sqs', 'eventSourceARN': 'arn:aws:sqs:us-east-1:141051459377:BrRequestSmootherStack-HoldNextBatchQueueF9A91014-tZOiOs2UNVTB.fifo', 'awsRegion': 'us-east-1'}]}
    
#     handler(e, {})
