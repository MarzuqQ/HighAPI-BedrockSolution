import json
import os
import boto3
from datetime import datetime

dynamodb = boto3.resource('dynamodb')
reporting_table = dynamodb.Table('ReportingMetadataTable')

def handler(event, context):
    """
    Lambda handler for processing DynamoDB stream events and updating the reporting table.
    """
    try:
        for record in event['Records']:
            # Ensure this is a DynamoDB Stream event
            if record['eventSource'] != 'aws:dynamodb':
                continue

            # Get the new image of the item (if it exists)
            if 'NewImage' in record['dynamodb']:
                new_image = record['dynamodb']['NewImage']
                
                # Extract values, providing defaults if keys are missing
                request_id = new_image.get('request_id', {}).get('S', 'Unknown')
                status = new_image.get('status', {}).get('S', 'Unknown')
                created_at = new_image.get('created_at', {}).get('S', datetime.now().isoformat())
                
                # Ensure request_id is not empty
                if request_id == 'Unknown':
                    print(f"Error: Missing request_id in record: {json.dumps(record)}")
                    continue

                # Update the reporting table
                reporting_table.put_item(
                    Item={
                        'request_id': request_id,
                        'status': status,
                        'created_at': created_at,
                        'last_updated': datetime.now().isoformat()
                    }
                )
                
                print(f"Updated reporting for request {request_id}")

        return {
            'statusCode': 200,
            'body': json.dumps('Processing complete')
        }
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
if __name__ == "__main__":
    os.environ["REPORTING_TABLE"] = "BrRequestSmootherStack-ReportingTableB3B457EE-1KVJKBCCW0AJ0"
    e = {}
    handler(e, {})