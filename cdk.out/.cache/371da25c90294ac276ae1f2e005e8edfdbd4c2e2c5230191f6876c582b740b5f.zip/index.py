import json
import boto3
import os
from botocore.exceptions import ClientError
from datetime import datetime
import logging

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
s3 = boto3.client('s3')
sqs = boto3.client('sqs')
dynamodb = boto3.resource('dynamodb')
bedrock = boto3.client('bedrock-runtime')


def update_dynamodb_error(table, request_id, error_message):
    table.update_item(
        Key={'request_id': request_id},
        UpdateExpression="SET request_status = :status, updated_at = :time, error_message = :error",
        ExpressionAttributeValues={
            ':status': 'FAILED',
            ':time': datetime.utcnow().isoformat(),
            ':error': error_message
        }
    )
    logger.info(f"Updated DynamoDB for request {request_id}: status set to FAILED")

def handler(event, context):
    # Environment variables
    S3_BUCKET = os.environ['S3_BUCKET_NAME']
    DYNAMODB_TABLE = os.environ['DYNAMODB_TABLE_NAME']
    RESULTS_QUEUE_URL = os.environ['RESULTS_QUEUE_URL']

    logger.error(f"Jared practice Event: {event}")
    for record in event['Records']:
        # Parse the message from SQS
        message = json.loads(record['body'])
        request_id = message['request_id']
        
        try:
            # Retrieve request data from S3
            s3_key = f'{request_id}.json'
            response = s3.get_object(Bucket=S3_BUCKET, Key=s3_key)
            request_data_str = response['Body'].read().decode('utf-8')
            
            # Validate JSON format
            try:
                request_data = json.loads(request_data_str)
                logger.info(f"Request data for {request_id}: {json.dumps(request_data)}")
            except json.JSONDecodeError:
                raise ValueError(f"Invalid JSON format for request {request_id}")
            
            # Update DynamoDB to flag the request as in progress
            table = dynamodb.Table(DYNAMODB_TABLE)
            table.update_item(
                Key={'request_id': request_id},
                UpdateExpression="SET request_status = :status, updated_at = :time",
                ExpressionAttributeValues={
                    ':status': 'IN_PROGRESS',
                    ':time': datetime.utcnow().isoformat()
                }
            )
            
            logger.info(f"Updated DynamoDB for request {request_id}: status set to IN_PROGRESS")

            # Extract parameters from the request data
            messages = request_data.get('messages', [])
            model_id = request_data.get('model_id')

            # Ensure all required parameters are present
            if not (messages and model_id):
                raise ValueError("Missing required fields: 'messages' or 'model_id'")

            # Extract system message if present
            system = []
            if messages and messages[0]['role'] == 'system':
                system = [{"text": messages[0]['content'][0]['text']}]
                messages = messages[1:]  # Remove system message from messages

            # Prepare the converse parameters
            converse_params = {
                "modelId": model_id,
                "messages": messages,
            }
            
            # Only include system if it's not empty
            if system:
                converse_params["system"] = system

            # Call Bedrock API using the Converse API
            bedrock_response = bedrock.converse(**converse_params)
            logger.info(f"Raw Bedrock response: {bedrock_response}")

            # Extract the response
            if 'output' not in bedrock_response or 'message' not in bedrock_response['output']:
                raise ValueError("Invalid response structure from Bedrock API")

            message_content = bedrock_response['output']['message']
            
            if 'content' not in message_content or not message_content['content']:
                raise ValueError("No content in message response")

            completion = message_content['content'][0].get('text', "No content returned")

            try:
                # Try to parse the completion string into a JSON object
                parsed_completion = json.loads(completion)
                result = parsed_completion
            except json.JSONDecodeError:
                logger.warning(f"Failed to parse completion as JSON")
                result = completion

            # Prepare and send SQS message
            sqs_message = {
                'request_id': request_id,
                'original_request': messages,
                'result': result
            }

            sqs_response = sqs.send_message(
                QueueUrl=RESULTS_QUEUE_URL,
                MessageBody=json.dumps(sqs_message)
            )
            logger.info(f"Message sent to SQS. MessageId: {sqs_response['MessageId']}")

            # Update DynamoDB to mark success
            table.update_item(
                Key={'request_id': request_id},
                UpdateExpression="SET request_status = :status, updated_at = :time",
                ExpressionAttributeValues={
                    ':status': 'COMPLETED',
                    ':time': datetime.utcnow().isoformat()
                }
            )
            logger.info(f"Updated DynamoDB for request {request_id}: status set to COMPLETED")
            
        except ClientError as e:
            logger.error(f"AWS service error processing request {request_id}: {str(e)}")
            update_dynamodb_error(table, request_id, str(e))
        except ValueError as e:
            logger.error(f"Validation error for request {request_id}: {str(e)}")
            update_dynamodb_error(table, request_id, str(e))
        except Exception as e:
            logger.error(f"Unexpected error processing request {request_id}: {str(e)}", exc_info=True)
            update_dynamodb_error(table, request_id, str(e))
            raise
        
    return {
        'statusCode': 200,
        'body': json.dumps('Processing complete')
    }


# if __name__ == "__main__":
#     os.environ['S3_BUCKET_NAME'] = 'brrequestsmootherstack-bedrockcallsbucket5aed0cf9-flxvjkwbkxl4'
#     os.environ['DYNAMODB_TABLE_NAME'] = 'BrRequestSmootherStack-RequestsTable419243C7-1IG49OBTTYD64'
#     os.environ['RESULTS_QUEUE_URL'] = 'https://sqs.us-east-1.amazonaws.com/141051459377/BrRequestSmootherStack-BedrockResultsQueue64EE975B-kc8aot8jIcmC'
#     e = {

#     }
    
#     handler({}, {})
