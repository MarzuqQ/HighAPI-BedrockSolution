import json
import boto3
import os
from botocore.exceptions import ClientError
from datetime import datetime
import logging

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
step_functions = boto3.client('stepfunctions')

# Environment variables
S3_BUCKET = os.environ['S3_BUCKET_NAME']
DYNAMODB_TABLE = os.environ['DYNAMODB_TABLE_NAME']
STEP_FUNCTION_ARN = os.environ['STEP_FUNCTION_ARN']

def lambda_handler(event, context):
    print(event)
    for record in event['Records']:
        # Parse the message from SQS
        message = json.loads(record['body'])
        request_id = message['request_id']
        
        try:
            # Retrieve request data from S3
            s3_key = f'{request_id}.json'
            response = s3.get_object(Bucket=S3_BUCKET, Key=s3_key)
            request_data_str = response['Body'].read().decode('utf-8')
            
            # Validate JSON format
            try:
                request_data = json.loads(request_data_str)
                logger.info(f"Request data for {request_id}: {json.dumps(request_data)}")
            except json.JSONDecodeError:
                raise ValueError(f"Invalid JSON format for request {request_id}")
            
            # Update DynamoDB to flag the request as in progress
            table = dynamodb.Table(DYNAMODB_TABLE)
            table.update_item(
                Key={'request_id': request_id},
                UpdateExpression="SET request_status = :status, updated_at = :time",
                ExpressionAttributeValues={
                    ':status': 'IN_PROGRESS',
                    ':time': datetime.utcnow().isoformat()
                }
            )
            
            logger.info(f"Updated DynamoDB for request {request_id}: status set to IN_PROGRESS")
            
            # Prepare input for Step Function
            step_function_input = {
                'request_id': request_id,
                'data': request_data  # Pass the entire request_data  
            }
            
            print(step_function_input)

            # Start Step Function execution
            step_function_response = step_functions.start_execution(
                stateMachineArn=STEP_FUNCTION_ARN,
                input=json.dumps(step_function_input)
            )
            
            logger.info(f"Started Step Function execution for request {request_id}: {step_function_response['executionArn']}")
            
        except ClientError as e:
            logger.error(f"AWS service error processing request {request_id}: {str(e)}")
            update_dynamodb_error(table, request_id, str(e))
        except ValueError as e:
            logger.error(f"Validation error for request {request_id}: {str(e)}")
            update_dynamodb_error(table, request_id, str(e))
        except Exception as e:
            logger.error(f"Unexpected error processing request {request_id}: {str(e)}", exc_info=True)
            update_dynamodb_error(table, request_id, str(e))
            raise
        
    return {
        'statusCode': 200,
        'body': json.dumps('Processing complete')
    }

def update_dynamodb_error(table, request_id, error_message):
    table.update_item(
        Key={'request_id': request_id},
        UpdateExpression="SET request_status = :status, updated_at = :time, error_message = :error",
        ExpressionAttributeValues={
            ':status': 'FAILED',
            ':time': datetime.utcnow().isoformat(),
            ':error': error_message
        }
    )
    logger.info(f"Updated DynamoDB for request {request_id}: status set to FAILED")
