import json
import boto3
import os
from botocore.exceptions import ClientError
from datetime import datetime
import logging

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
bedrock = boto3.client('bedrock-runtime')
dynamodb = boto3.resource('dynamodb')
sqs = boto3.client('sqs')

# Environment variables
DYNAMODB_TABLE = os.environ['DYNAMODB_TABLE_NAME']
SQS_QUEUE_URL = os.environ['RESULTS_QUEUE_URL']

def lambda_handler(event, context):
    logger.info(f"Received event: {json.dumps(event)}")
    
    try:
        # Extract parameters from the event
        messages = event.get('messages', [])
        model_id = event.get('model_id')
        request_id = event.get('request_id')
        
        # Ensure all required parameters are present
        if not (messages and model_id and request_id):
            raise ValueError("Missing required fields: 'messages', 'model_id', or 'request_id'")

        # Extract system message if present
        system = []
        if messages and messages[0]['role'] == 'system':
            system = [{"text": messages[0]['content'][0]['text']}]
            messages = messages[1:]  # Remove system message from messages

        # Prepare the converse parameters
        converse_params = {
            "modelId": model_id,
            "messages": messages,
        }
        
        # Only include system if it's not empty
        if system:
            converse_params["system"] = system

        # Call Bedrock API using the Converse API
        response = bedrock.converse(**converse_params)
        
        # Log the response for debugging
        logger.info(f"Raw Bedrock response: {response}")

        # Extract the response from the 'output' field and then the 'message' field
        if 'output' not in response or 'message' not in response['output']:
            raise ValueError("Invalid response structure from Bedrock API")

        message_content = response['output']['message']
        
        # Extract the text from the message content
        if 'content' not in message_content or not message_content['content']:
            raise ValueError("No content in message response")

        completion = message_content['content'][0].get('text', "No content returned")

        try:
            # Try to parse the completion string into a JSON object
            parsed_completion = json.loads(completion)
            
            # Prepare the message for SQS with both request and response
            sqs_message = {
                'request_id': request_id,
                'original_request': messages,  # Include the original request
                'result': parsed_completion  # This will be the entire JSON object, not a string
            }
        except json.JSONDecodeError as e:
            # If parsing fails, use the original string
            logger.warning(f"Failed to parse completion as JSON: {str(e)}")
            sqs_message = {
                'request_id': request_id,
                'original_request': messages,
                'result': completion  # Use the original string if parsing fails
            }

        # Send result to SQS
        sqs_response = sqs.send_message(
            QueueUrl=SQS_QUEUE_URL,
            MessageBody=json.dumps(sqs_message)
        )
        logger.info(f"Message sent to SQS. MessageId: {sqs_response['MessageId']}")

        # Update DynamoDB to mark the request as completed
        table = dynamodb.Table(DYNAMODB_TABLE)
        table.update_item(
            Key={'request_id': request_id},
            UpdateExpression="SET request_status = :status, updated_at = :time",
            ExpressionAttributeValues={
                ':status': 'COMPLETED',
                ':time': datetime.utcnow().isoformat()
            }
        )
        logger.info(f"DynamoDB updated for request {request_id}: status set to COMPLETED")

        return {
            'statusCode': 200,
            'body': json.dumps({
                'request_id': request_id,
                'result': parsed_completion if 'parsed_completion' in locals() else completion,
                'message': 'Processing complete'
            })
        }
    
    except ValueError as ve:
        error_message = str(ve)
        logger.error(f"Validation error: {error_message}")
    except ClientError as ce:
        error_message = f"AWS service error: {str(ce)}"
        logger.error(error_message)
    except Exception as e:
        error_message = f"Unexpected error: {str(e)}"
        logger.error(error_message)
    
    # If an error occurred, update DynamoDB to indicate failure
    try:
        table = dynamodb.Table(DYNAMODB_TABLE)
        table.update_item(
            Key={'request_id': request_id},
            UpdateExpression="SET request_status = :status, error_message = :error, updated_at = :time",
            ExpressionAttributeValues={
                ':status': 'FAILED',
                ':error': error_message,
                ':time': datetime.utcnow().isoformat()
            }
        )
        logger.info(f"DynamoDB updated for request {request_id}: status set to FAILED")
    except Exception as update_error:
        logger.error(f"Failed to update DynamoDB with error status: {str(update_error)}")

    return {
        'statusCode': 500,
        'body': json.dumps({
            'request_id': request_id,
            'error': error_message
        })
    }
